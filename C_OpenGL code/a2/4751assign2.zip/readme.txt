                            README
                            
                            
- all the questions are saved to one .c file, called bresenham.c
- to run this code from the labnet machines which already have the necessary 
  programs installed, you'll need to run the command from terminal:
  "gcc -o foo foo.c -lglut -lGLU -lGL -lm"
- if this doesn't work, however, I have included the makefile which all you
  need to do is cd to the directory the file is located and run the command 
  "make" then ./bresenham regardless if you use the makefile or the code
  given abve. All changes necessary to run the makefile have already been 
  made, so simply run the makefile.
- in the bresenham.c file, you need to modify the argument that currently exists
  "line" to the name of the input file you wish to use. this is on line 112.                 
